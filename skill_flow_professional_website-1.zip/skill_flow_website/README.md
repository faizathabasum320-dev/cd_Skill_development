# SkillFlow — Professional React Workflow Website

## Stack
- React 18
- Vite
- Plain CSS
- No backend dependency

## Run locally
```bash
npm install
npm run dev
```

Then open the local URL shown by Vite.

## Included
- Professional corporate responsive design
- Interactive workflow cards
- Role-based login UI for Student / Trainer / Mentor / Admin
- Assessment-2 75% interactive decision
- Training vs Mentorship routing state
- Mini Tasks → Resume → Hiring career path
- Resigned-person re-entry path
- Mobile responsive vertical workflow
- Backend/API-ready UI structure (replace demo handlers with API calls later)

## Important
The login is intentionally a frontend demo. Connect it to your backend authentication endpoint when the API is available.
