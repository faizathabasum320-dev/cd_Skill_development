import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const steps = [
  { id:"login", title:"Person Login", subtitle:"Access your journey", icon:"person", color:"navy",
    details:["Student Login","Trainer Login","Mentor Login","Admin Login"] },
  { id:"industry", title:"Industry Requirement", subtitle:"Demand skills", icon:"people", color:"blue",
    details:["Industry demand analysis","Role-specific skill requirements","Current market expectations"] },
  { id:"roadmap", title:"Skill Roadmap", subtitle:"Complete skill map", icon:"bulb", color:"teal",
    details:["Fundamentals","Moderate skills","Advanced skills","Personalized learning path"] },
  { id:"assessment1", title:"Assessment-1", subtitle:"Find your skill gap", icon:"document", color:"blue",
    details:["Baseline assessment","Knowledge and practical evaluation","Skill-gap score"] },
  { id:"gap", title:"Skill Gap Analysis", subtitle:"Fundamentals → Advanced", icon:"search", color:"navy",
    details:["1. Fundamentals","2. Moderate","3. Advanced","Gap identification"] },
  { id:"training", title:"Training", subtitle:"Based on skill gap", icon:"trainer", color:"teal",
    details:["Targeted training modules","Trainer-led learning","Practice and progress tracking"] },
  { id:"assessment2", title:"Assessment-2", subtitle:"Knowledge analysis", icon:"document", color:"blue",
    details:["Post-training assessment","Knowledge validation","Readiness evaluation"] },
  { id:"mentorship", title:"Mentorship", subtitle:"Based on domains", icon:"mentor", color:"teal",
    details:["Domain mentor matching","Career guidance","Industry-oriented support"] },
  { id:"tasks", title:"Mini Tasks", subtitle:"Projects", icon:"task", color:"navy",
    details:["Small practical projects","Real-world problem solving","Portfolio-ready outcomes"] },
  { id:"resume", title:"Resume", subtitle:"Building resume", icon:"resume", color:"blue",
    details:["Profile building","Project highlights","Resume generation"] },
  { id:"hiring", title:"Hiring", subtitle:"Job selection", icon:"job", color:"teal",
    details:["Role matching","Job selection","Hiring pipeline"] }
];

const roles = ["Student", "Trainer", "Mentor", "Admin"];

function Icon({name}) {
  const common = { viewBox:"0 0 48 48", fill:"none", stroke:"currentColor", strokeWidth:"2.2", strokeLinecap:"round", strokeLinejoin:"round" };
  const paths = {
    person:<><circle cx="24" cy="17" r="7"/><path d="M11 39c1.5-7 6-11 13-11s11.5 4 13 11"/><path d="M17 26c-3-2-5-5-5-9 0-7 5-12 12-12s12 5 12 12c0 4-2 7-5 9"/></>,
    people:<><circle cx="16" cy="17" r="5"/><circle cx="32" cy="17" r="5"/><path d="M7 37c1-6 4-9 9-9s8 3 9 9"/><path d="M23 37c1-6 4-9 9-9s8 3 9 9"/></>,
    bulb:<><path d="M18 29c-2-2-4-5-4-9a10 10 0 0 1 20 0c0 4-2 7-4 9-1 1-2 2-2 4H20c0-2-1-3-2-4Z"/><path d="M20 37h8M21 42h6"/><path d="M24 4v-2M9 11 7 9M39 11l2-2"/></>,
    document:<><rect x="12" y="6" width="25" height="35" rx="2"/><path d="M18 17h13M18 23h13M18 29h8"/><path d="M31 6v7h6"/><circle cx="34" cy="18" r="3"/></>,
    search:<><circle cx="21" cy="21" r="10"/><path d="m29 29 10 10"/><path d="M11 38c2-4 5-6 9-6"/><path d="M10 12 7 9M31 12l3-3"/></>,
    trainer:<><circle cx="24" cy="16" r="7"/><path d="M11 40c1-7 5-11 13-11s12 4 13 11"/><rect x="7" y="7" width="13" height="9" rx="2"/><path d="M10 12h7"/></>,
    mentor:<><circle cx="24" cy="17" r="7"/><path d="M10 40c1-7 6-11 14-11s13 4 14 11"/><circle cx="36" cy="31" r="6"/><path d="m33 31 2 2 4-5"/></>,
    task:<><circle cx="17" cy="17" r="7"/><path d="m13 17 3 3 5-7"/><rect x="27" y="10" width="12" height="24" rx="2"/><path d="M30 16h6M30 22h6M30 28h4"/><path d="m7 37 5-5 5 5"/></>,
    resume:<><rect x="13" y="6" width="23" height="36" rx="2"/><circle cx="24" cy="16" r="4"/><path d="M19 25h10M18 30h12M18 35h8"/></>,
    job:<><rect x="7" y="13" width="34" height="25" rx="3"/><path d="M17 13V9h14v4M7 23h34M20 23v4h8v-4"/><path d="M14 31h7M27 31h7"/></>
  };
  return <svg {...common}>{paths[name]}</svg>;
}

function Arrow({direction="right", label}) {
  return <div className={`flow-arrow ${direction}`} aria-hidden="true">
    {label && <span>{label}</span>}
    <i></i>
  </div>;
}

function App() {
  const [active, setActive] = useState(null);
  const [role, setRole] = useState(null);
  const [score, setScore] = useState(80);
  const [loggedIn, setLoggedIn] = useState(false);

  const openStep = id => setActive(steps.find(s => s.id === id));

  return (
    <div className="app">
      <header className="topbar">
        <a className="brand" href="#top">
          <span className="brand-mark">SF</span>
          <span>Skill<span>Flow</span></span>
        </a>
        <nav>
          <a href="#workflow">Workflow</a>
          <a href="#score">Assessment</a>
          <a href="#career">Career Path</a>
        </nav>
        <button className="header-login" onClick={() => setRole("Student")}>
          {loggedIn ? "Dashboard" : "Login"}
        </button>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">CAREER DEVELOPMENT PLATFORM</div>
            <h1>From <em>skill gap</em> to<br/>career opportunity.</h1>
            <p>One connected workflow for discovering industry requirements, building skills, proving knowledge, receiving mentorship and moving toward the right job.</p>
            <div className="hero-actions">
              <button className="primary" onClick={() => document.getElementById("workflow").scrollIntoView({behavior:"smooth"})}>Explore Workflow <span>→</span></button>
              <button className="secondary" onClick={() => setRole("Student")}>Start as Student</button>
            </div>
            <div className="hero-stats">
              <div><strong>11</strong><span>Core stages</span></div>
              <div><strong>75%</strong><span>Decision threshold</span></div>
              <div><strong>4</strong><span>User roles</span></div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
            <div className="center-card"><div className="mini-icon"><Icon name="bulb"/></div><strong>Skill Journey</strong><span>Discover → Learn → Prove → Grow</span></div>
            <div className="floating-card fc1"><b>Assessment</b><span>82% readiness</span></div>
            <div className="floating-card fc2"><b>Industry Match</b><span>Strong demand</span></div>
            <div className="floating-card fc3"><b>Career</b><span>Job-ready profile</span></div>
          </div>
        </section>

        <section className="workflow-section" id="workflow">
          <div className="section-heading">
            <div><div className="eyebrow">THE COMPLETE JOURNEY</div><h2>Professional skill-to-career workflow</h2></div>
            <p>Every stage is connected. Select any step to see what happens inside it.</p>
          </div>

          <div className="flow-board">
            <div className="flow-row top-row">
              {steps.slice(0,7).map((step,i) => (
                <React.Fragment key={step.id}>
                  <button className={`step-card ${step.color}`} onClick={() => openStep(step.id)}>
                    <span className="step-number">{String(i+1).padStart(2,"0")}</span>
                    <div className="icon-box"><Icon name={step.icon}/></div>
                    <div className="step-title">{step.title}</div>
                    <div className="step-subtitle">{step.subtitle}</div>
                    <span className="view-step">View details +</span>
                  </button>
                  {i < 6 && <Arrow />}
                </React.Fragment>
              ))}
            </div>

            <div className="decision-branch">
              <div className="branch-line"></div>
              <div className="branch-label less">LESS THAN <b>75%</b></div>
              <div className="branch-label more">MORE THAN <b>75%</b></div>
            </div>

            <div className="decision-panel">
              <div className="decision-copy">
                <span className="eyebrow">ASSESSMENT DECISION</span>
                <h3>Where does the learner go next?</h3>
                <p>Use the second assessment score to determine whether additional training or domain mentorship is the right next step.</p>
              </div>
              <div className="score-control" id="score">
                <label>Assessment-2 score <strong>{score}%</strong></label>
                <input type="range" min="0" max="100" value={score} onChange={e=>setScore(+e.target.value)} />
                <div className="range-labels"><span>0%</span><span>75% threshold</span><span>100%</span></div>
                <div className={`result ${score > 75 ? "mentor-result" : "training-result"}`}>
                  {score > 75 ? "→ Mentorship" : "→ Training"}
                </div>
              </div>
            </div>

            <div className="flow-row bottom-row">
              <button className="step-card resigned" onClick={() => setActive({title:"Resigned Person",subtitle:"Searching for a new job",icon:"person",details:["Re-enter the skill development journey","Refresh skills against current industry demand","Build a stronger job-ready profile"]})}>
                <div className="icon-box"><Icon name="person"/></div><div className="step-title">Resigned Person</div><div className="step-subtitle">Searching for a new job</div>
              </button>
              <div className="return-line">↗ Re-enter journey</div>
              <button className="step-card teal" onClick={() => openStep("tasks")}><span className="step-number">09</span><div className="icon-box"><Icon name="task"/></div><div className="step-title">Mini Tasks</div><div className="step-subtitle">Projects</div><span className="view-step">View details +</span></button>
              <Arrow direction="left"/>
              <button className="step-card blue" onClick={() => openStep("resume")}><span className="step-number">10</span><div className="icon-box"><Icon name="resume"/></div><div className="step-title">Resume</div><div className="step-subtitle">Building resume</div><span className="view-step">View details +</span></button>
              <Arrow direction="left"/>
              <button className="step-card navy" onClick={() => openStep("hiring")}><span className="step-number">11</span><div className="icon-box"><Icon name="job"/></div><div className="step-title">Hiring</div><div className="step-subtitle">Job selection</div><span className="view-step">View details +</span></button>
            </div>
          </div>
        </section>

        <section className="roles-section">
          <div className="section-heading centered">
            <div><div className="eyebrow">ROLE-BASED ACCESS</div><h2>One platform, four experiences</h2></div>
            <p>Each user gets a focused workspace while staying connected to the same career workflow.</p>
          </div>
          <div className="role-grid">
            {roles.map((r,i)=><button key={r} className="role-card" onClick={()=>setRole(r)}>
              <span className="role-icon"><Icon name={["person","trainer","mentor","people"][i]}/></span>
              <span><b>{r} Login</b><small>{i===0?"Learning & assessments":i===1?"Training & progress":i===2?"Guidance & domains":"Platform administration"}</small></span>
              <strong>→</strong>
            </button>)}
          </div>
        </section>

        <section className="career-section" id="career">
          <div className="career-card">
            <div><div className="eyebrow">OUTCOME</div><h2>Build evidence.<br/><em>Build opportunity.</em></h2><p>Mini projects, mentorship and a structured resume turn learning activity into a career-ready profile.</p></div>
            <div className="outcome-flow">
              <span>Skills</span><i>→</i><span>Projects</span><i>→</i><span>Resume</span><i>→</i><strong>Hiring</strong>
            </div>
          </div>
        </section>
      </main>

      <footer><span>© 2026 SkillFlow</span><span>Professional skill development workflow</span></footer>

      {active && <div className="modal-backdrop" onClick={()=>setActive(null)}>
        <div className="modal" onClick={e=>e.stopPropagation()}>
          <button className="close" onClick={()=>setActive(null)}>×</button>
          <div className="modal-icon"><Icon name={active.icon}/></div>
          <div className="eyebrow">WORKFLOW STAGE</div>
          <h2>{active.title}</h2><p className="modal-sub">{active.subtitle}</p>
          <ul>{active.details.map(d=><li key={d}>✓ {d}</li>)}</ul>
          <button className="primary full" onClick={()=>{setActive(null);setRole("Student")}}>Continue to this stage →</button>
        </div>
      </div>}

      {role && <div className="modal-backdrop" onClick={()=>setRole(null)}>
        <div className="login-modal" onClick={e=>e.stopPropagation()}>
          <button className="close" onClick={()=>setRole(null)}>×</button>
          <div className="login-brand"><span className="brand-mark">SF</span><div><b>{role} Login</b><small>Secure role-based access</small></div></div>
          <label>Email address</label><input type="email" placeholder="you@example.com"/>
          <label>Password</label><input type="password" placeholder="••••••••"/>
          <button className="primary full" onClick={()=>{setLoggedIn(true);setRole(null)}}>Sign in →</button>
          <p className="login-note">Frontend demo — connect this form to your authentication API when the backend is ready.</p>
        </div>
      </div>}
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
